-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Nov 2023 pada 05.46
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `karyawan3`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_login` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nik` int(20) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `ttl` varchar(200) NOT NULL,
  `pendidikan` varchar(100) NOT NULL,
  `status` varchar(250) NOT NULL,
  `departemen` varchar(255) NOT NULL,
  `level` int(50) NOT NULL,
  `grade` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_login`, `username`, `password`, `nama`, `nik`, `alamat`, `ttl`, `pendidikan`, `status`, `departemen`, `level`, `grade`) VALUES
(1, 'saka', '202cb962ac59075b964b07152d234b70', 'safaka', 123456, 'jombang', 'jombang, 3 agustus 2005', 'SMA', 'AKTIF', 'HR', 4, 4),
(2, 'sifa', '1234', 'sifaka', 12345, 'jember', 'jember, 6 april 2009', 'SMA', 'aktif', 'IT', 3, 3),
(3, 'gass', '827ccb0eea8a706c4c34a16891f84e7b', 'faizah', 123456789, 'jombang', 'bandung, 3 april 2002', 'S1', 'aktif', 'HR', 3, 4),
(4, 'latul', '92daa86ad43a42f28f4bf58e94667c95', 'latul', 1123456789, 'jombang', 'bekasi, 3 mei 2009', 'SMA', 'AKTIF', 'IT', 4, 3);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_login`),
  ADD UNIQUE KEY `nik` (`nik`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
